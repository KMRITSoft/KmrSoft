export class Slider{
    path : string;
    alt: string;
    title : string;
    subtitle :string;
    constructor( path : string,alt : string,title: string,subtitle : string) {
        this.path = path;
        this.alt = alt;
        this.title = title;
        this.subtitle = subtitle;
      }
}